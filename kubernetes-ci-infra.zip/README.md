# Kubernetes CI/CD Infrastructure

🚀 **Kubernetes CI/CD Infrastructure** automates deployment using GitLab CI/CD, Kubernetes, and Helm for seamless application management.

## Features

- **GitLab CI/CD Integration** – Supports automated deployments.
- **Kubernetes Configuration** – Includes Ingress, RBAC, and Auto-scaling.
- **Helm Charts** – Simplifies Kubernetes deployment.
- **Security & Access Control** – Uses Role-Based Access Control (RBAC).
- **Persistent Storage** – Configured via Persistent Volume Claims (PVC).

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/Boomtokn/kubernetes-ci-infra.git
   cd kubernetes-ci-infra
   ```

2. Deploy using Helm:
   ```bash
   helm install my-app helm/
   ```

## Contributing

1. Fork the repository.
2. Create a feature branch (`git checkout -b feature-branch`).
3. Commit changes (`git commit -m "Added feature"`).
4. Push to the branch (`git push origin feature-branch`).
5. Open a Pull Request.

## License

This project is licensed under the MIT License.
